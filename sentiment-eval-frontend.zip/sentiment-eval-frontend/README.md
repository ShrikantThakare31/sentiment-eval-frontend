# Sentiment Evaluation Frontend

Run:
1. cd sentiment-eval-frontend
2. npm install
3. npm run dev

This frontend expects a backend at http://localhost:8000/sentiment_eval that accepts { emails: [...], version: 'v1'|'v2' }.
If backend isn't present, a local heuristic will be used.
