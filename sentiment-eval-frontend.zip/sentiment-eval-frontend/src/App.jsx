import { useState } from 'react'
import axios from 'axios'

const DEFAULT_EMAILS = Array.from({length:10}).map((_,i)=>`Sample email ${i+1}: I'm not happy with the service.`)

export default function App(){
  const [emails, setEmails] = useState(DEFAULT_EMAILS)
  const [results, setResults] = useState(null)
  const [loading, setLoading] = useState(false)

  async function runEvaluation(version='v1'){
    setLoading(true)
    setResults(null)
    try{
      const res = await axios.post('http://localhost:8000/sentiment_eval', { emails, version }, { timeout: 4000 })
      setResults(res.data)
    }catch(e){
      // Local mock evaluation
      const out = emails.map(e=>{
        const t = e.toLowerCase()
        let sentiment = 'neutral'
        if(t.includes('not')||t.includes("don't")||t.includes('unhappy')||t.includes('bad')) sentiment = 'negative'
        else if(t.includes('great')||t.includes('love')||t.includes('excellent')) sentiment = 'positive'
        const confidence = Math.round(70 + Math.random()*25)
        return { sentiment, confidence, hidden_reasoning: 'Local heuristic: keyword match' }
      })
      setResults({ version, outputs: out })
    }finally{ setLoading(false) }
  }

  function updateEmail(i, val){
    const arr = [...emails]; arr[i]=val; setEmails(arr)
  }

  return (
    <div className="container">
      <h1>Sentiment Analysis Prompt Evaluation</h1>
      <p className="small">Enter up to 10 emails and compare prompt v1 vs v2.</p>

      {emails.map((em, i)=>(
        <textarea key={i} rows={3} className="input" value={em} onChange={e=>updateEmail(i, e.target.value)} />
      ))}

      <div style={{display:'flex', gap:8}}>
        <button className="btn" onClick={()=>runEvaluation('v1')} disabled={loading}>{loading ? 'Running...' : 'Run Prompt v1'}</button>
        <button className="btn" onClick={()=>runEvaluation('v2')} disabled={loading}>{loading ? 'Running...' : 'Run Prompt v2'}</button>
      </div>

      {results && (
        <div className="card">
          <h3>Results — {results.version}</h3>
          <table style={{width:'100%', borderCollapse:'collapse'}}>
            <thead>
              <tr><th>Email</th><th>Sentiment</th><th>Confidence</th><th>Reason</th></tr>
            </thead>
            <tbody>
              {results.outputs.map((o, i)=>(
                <tr key={i} style={{borderTop:'1px solid #eee'}}>
                  <td style={{padding:'8px'}}>{emails[i]}</td>
                  <td style={{padding:'8px'}}>{o.sentiment}</td>
                  <td style={{padding:'8px'}}>{o.confidence}%</td>
                  <td style={{padding:'8px'}}><details><summary>view</summary><pre style={{whiteSpace:'pre-wrap'}}>{o.hidden_reasoning}</pre></details></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="card">
        <h3>Notes</h3>
        <ul>
          <li>Prompt v1: simple instruction — may be inconsistent on edge cases.</li>
          <li>Prompt v2: include explicit labeling rules and ask for confidence on 0-100 scale.</li>
        </ul>
      </div>
    </div>
  )
}
